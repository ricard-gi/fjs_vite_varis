import Titol from "./Titol";
import Caixa from "./Caixa"
import Alerta from "./Alerta";

import Logo from "./assets/gilera.png";
import Calculadora from "./Calculadora";

function App () {


  return (
    <>
      <Calculadora />
    
    </>
  )


/*
  return (
    <>

     <Titol contingut="el titol de la pàgina" variant="red" />
     <Titol contingut="el titol de la pàgina" variant="green" />

     <img src="/img/benelli.jpg" alt="benelli" />
    
     <img src={Logo} alt="xx" />


     <Caixa >
        <p className="text-red-500 w-1/2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro explicabo accusamus earum nesciunt illum, expedita voluptates repellendus veritatis ratione? Quis eligendi ipsum laudantium excepturi officiis amet nostrum id eveniet nemo?</p>
     </Caixa>

     <div>
      <p>Lorem ipsum dolor sit.</p>
     </div>

     <Alerta variant="pink" missatge="Alerta a la població" />
     <Alerta variant="green" missatge="Alerta a la població" />

    </>
  )
*/
}

export default App;