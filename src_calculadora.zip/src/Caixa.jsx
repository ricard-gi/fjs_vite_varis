
import "./Caixa.css";


function Caixa({children}){

    return (
        <div className="caixa">
            {children}
        </div>
    )
}

export default Caixa;