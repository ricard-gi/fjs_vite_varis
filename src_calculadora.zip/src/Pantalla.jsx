

function Pantalla({valor}){


    return (
        <>
            <p className="border my-4 text-center py-2">{valor}</p>

        </>
    )
}

export default Pantalla;